package com.futuregenic.homefit.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.futuregenic.homefit.R;
import com.futuregenic.homefit.models.MDAnswers;


import java.util.List;

public class AdapterQuestionsAnswersRecyclerView extends RecyclerView.Adapter<AdapterQuestionsAnswersRecyclerView.ViewHolder> {
    private OnClick listener;
    private List<MDAnswers> data;
    public AdapterQuestionsAnswersRecyclerView(List<MDAnswers> data){
        this.data = data;
    }

    @NonNull
    @Override
    public AdapterQuestionsAnswersRecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_questions_recycler_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterQuestionsAnswersRecyclerView.ViewHolder holder, final int position) {
        holder.answerTV.setText(data.get(position).getAnswer());
        holder.answerTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    static class ViewHolder extends RecyclerView.ViewHolder{
        TextView answerTV;
        ViewHolder(@NonNull View itemView) {
            super(itemView);
            answerTV = itemView.findViewById(R.id.ansText);
        }
    }

    public void setData(List<MDAnswers> data){
        this.data = data;
        notifyDataSetChanged();
    }


    public interface OnClick{
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnClick listener){
        this.listener = listener;
    }
}
