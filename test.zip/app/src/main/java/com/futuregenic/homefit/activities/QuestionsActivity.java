package com.futuregenic.homefit.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import com.futuregenic.homefit.R;
import com.futuregenic.homefit.adapters.AdapterQuestionsAnswersRecyclerView;
import com.futuregenic.homefit.models.MDAnswers;
import com.futuregenic.homefit.models.MDQuestions;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class QuestionsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView questionTV;
    LinearLayoutManager linearLayoutManager;
    List<MDQuestions> d;
    private int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        recyclerView = findViewById(R.id.recyclerView);
        questionTV = findViewById(R.id.questionsTV);
        loadData();
    }

    private void loadData() {
        d = new ArrayList<>();
        List<MDAnswers> list1 = new ArrayList<>();
        list1.add(new MDAnswers("Last week"));
        list1.add(new MDAnswers("Last Month"));
        list1.add(new MDAnswers("Last year"));
        d.add(new MDQuestions("When was the last time you worked out?", list1));

        List<MDAnswers> list2 = new ArrayList<>();
        list2.add(new MDAnswers("Daily"));
        list2.add(new MDAnswers("2x A day"));
        list2.add(new MDAnswers("Once a week "));
        d.add(new MDQuestions("How often did you work out?", list2));

        List<MDAnswers> list3 = new ArrayList<>();
        list3.add(new MDAnswers("Loose weight"));
        list3.add(new MDAnswers("Trim Down"));
        list3.add(new MDAnswers("Build Muscle"));
        d.add(new MDQuestions("What is your main goal?", list3));

        List<MDAnswers> list4 = new ArrayList<>();
        list4.add(new MDAnswers("15 min"));
        list4.add(new MDAnswers("30 min"));
        list4.add(new MDAnswers("1 hour"));
        d.add(new MDQuestions("How much time will you dedicate to daily workouts?", list4));

        List<MDAnswers> list5 = new ArrayList<>();
        list5.add(new MDAnswers("No"));
        list5.add(new MDAnswers("Average"));
        list5.add(new MDAnswers("Yes, Experienced lifter"));
        d.add(new MDQuestions("Do you have experience in weightlifting?", list5));

        List<MDAnswers> list6 = new ArrayList<>();
        list6.add(new MDAnswers("No"));
        list6.add(new MDAnswers("Basics"));
        list6.add(new MDAnswers("Yes fully equipped"));
        d.add(new MDQuestions("Do you have a home gym?", list6));

        setupRecyclerView();

    }

    private void setupRecyclerView() {
        linearLayoutManager = new LinearLayoutManager(this);
        final AdapterQuestionsAnswersRecyclerView adapter = new AdapterQuestionsAnswersRecyclerView(d.get(currentIndex).getAnswersList());
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);
        questionTV.setText(d.get(currentIndex).getQuestion());
        adapter.setOnItemClickListener(new AdapterQuestionsAnswersRecyclerView.OnClick() {
            @Override
            public void onItemClick(int position) {
                if (currentIndex < d.size()) {
                    if (currentIndex != d.size() - 1) {
                        currentIndex++;
                    }
                    questionTV.setText(d.get(currentIndex).getQuestion());
                    adapter.setData(d.get(currentIndex).getAnswersList());
                }
            }
        });
    }
}
