package com.futuregenic.homefit.models;

public class MDAnswers{
    private String answer;
    public MDAnswers(String answer){
        this.answer = answer;
    }
    public String getAnswer() {
        return answer;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }
}