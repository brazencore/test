package com.futuregenic.homefit.models;

import java.util.List;

public class MDQuestions {
    private String question;
    private List<MDAnswers> answersList;

    public MDQuestions(String question, List<MDAnswers> answers){
        this.question = question;
        this.answersList = answers;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public List<MDAnswers> getAnswersList() {
        return answersList;
    }

    public void setAnswersList(List<MDAnswers> answersList) {
        this.answersList = answersList;
    }
}


